﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Aman_VD_API.Models
{
    public partial class LkpPassangerCapacity
    {
        public LkpPassangerCapacity()
        {
            AmanVehicleDescriptions = new HashSet<AmanVehicleDescription>();
        }

        public int? Passangercapacity { get; set; }
        public int PassangercapacityId { get; set; }

        public virtual ICollection<AmanVehicleDescription> AmanVehicleDescriptions { get; set; }
    }
}
