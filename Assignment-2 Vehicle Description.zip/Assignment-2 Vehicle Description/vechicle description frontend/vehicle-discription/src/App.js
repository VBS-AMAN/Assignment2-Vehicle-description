import VehicleForm2 from './Components/VehicleForm2';
 import './App.css';

 import { Routes, Route, Navigate } from "react-router-dom";


// import Home from './components/Home';
// import VechicleDescription from './Components/VechicleDescription';


 function App() {
   return (
    <div className="App">
       <h1>Vehicle Description</h1>
       <VehicleForm2 />
       {/* <Routes>
        <Route path="/" element={<Home />} />
      <Route path="/VechicleDescription" element={<VechicleDescription />} />  */}


//         {/* If any route mismatches the upper 
//           route endpoints then, redirect triggers 
//           and redirects app to home component with to="/" */}
{/* //         <Navigate to="/" />
//       </Routes>
       */}
//     </div>
  );
}

 export default App;
