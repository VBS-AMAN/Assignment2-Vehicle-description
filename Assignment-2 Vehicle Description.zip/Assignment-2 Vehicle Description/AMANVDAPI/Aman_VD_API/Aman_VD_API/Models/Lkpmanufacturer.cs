﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Aman_VD_API.Models
{
    public partial class Lkpmanufacturer
    {
        public Lkpmanufacturer()
        {
            AmanVehicleDescriptions = new HashSet<AmanVehicleDescription>();
        }

        public string Manufacturer { get; set; }
        public int LkpManufacturerId { get; set; }

        public virtual ICollection<AmanVehicleDescription> AmanVehicleDescriptions { get; set; }
    }
}
