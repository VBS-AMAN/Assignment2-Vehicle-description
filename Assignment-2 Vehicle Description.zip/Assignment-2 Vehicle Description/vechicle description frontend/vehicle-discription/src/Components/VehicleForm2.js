import React
 from "react";
 function VehicleForm2(){
    return(
        
            
                <div>
                    <div>
                    <head> 
                        <title>Vehicle Description</title>
                    </head>
                    </div>
                    <div>
                    <form>
                        <body>      

                            <tr>
                                <td>      
                <label for="Manufacturer"> Manufacturer </label> </td>   
               
                <td>  
                <select>
                    <option value="Manufacturer">Manufacturer</option>
                    <option value="Maruti">Maruti</option>
                    <option value="Honda">Honda</option>
                </select>  
                </td>   
                </tr>
                <span>&nbsp;</span>
                <tr>
                                <td>  
                <label for="launching_year">Launching Year</label> </td> 
                <td> <input type="number" name="launching_year"></input>  
                 </td>   
                </tr>  <br /> 

                  <tr>
                    <td>
                 
          <label>Model</label>
               <select name="Model" size="4">  
              <option value="ZDI"> ZDI </option>  
              <option value="VDI"> VDI </option>  
              <option value="SDI"> SDI </option>  
             
   
                   </select>  
                   
                        </td>
                         </tr>
                   <br/>
                  <tr>
                    <td>
                <label for="VehicleName">Vehicle Name</label>
                </td>
                <td> 
                <input type="text" name="VehicleName" placeholder="VechicleName"></input> 
                </td>
                 {/* <span>&nbsp;</span> */}
                </tr>
                <br/>
                <tr>
                    <td>
                <label for="Vehicletype"> VehicleType</label>
                </td>
                <td>
                <select>
                    <option value="Vehicletpe">Vehicletype</option>
                    <option value="Maruti">Maruti</option>
                    <option value="Honda">Honda</option>
                </select>  
                </td>
                </tr> <br /> 
                 
                <tr>
                    <td>
                <label for="PassangerCapacity"> Passangercapacity</label>
                </td>
                <td>
                <select>
                    <option value="PassangerCapacity">Passangercapacity</option>
                    <option value="2">2</option>
                    <option value="5">5</option>
                </select>  
                {/* <span>&nbsp;</span>  */}
                </td>
                </tr>
                <br/>
                <tr>
                    <td>
                <label for="cost"> Cost(Lac)</label> 
                </td>
                <td>
        <input type="number" name="cost" placeholder="Minimumcost" />
        </td>
        <td>
        <input type="number" name="cost" placeholder="Maximumcost" />
        </td>
        </tr>
         <br/> 
                  <tr>
                    <td>
                <label for="Enginecapacity">EngineCapacity(CC)</label>
                </td>
                <td>
                <input type="number" name="Enginecapacity" placeholder="EngineCapacity"></input> 
                </td>
                </tr>
                 <br /> 

                  <tr>
                    <td>
                <label for="FuelType"> Fuel Type: </label> 
                </td>
               
                <td>
                <label for="Petrol">Petrol</label>
        <input type="radio" name="FuelType" value="1" onclick="checkedOnClick(this);" /> 
        
        <label for="Diesel">Diesel</label>
        <input type="radio" name="FuelType" value="2" onclick="checkedOnClick(this);" /> 
       
        </td>
       
       
          </tr>
         <br/>
        <tr>
            <td>
        <label for="EngineType">Engine Type</label>
        </td>
        <td>
                <input type="text" name="EngineType" placeholder="EngineType"></input>  <br /> <br />
                </td>
                </tr>
                <tr>
                <td>
                <label for="DriveType">Drive Type</label>
                </td>
                <td>
                <input type="text" name="DriveType" placeholder="DriveType"></input>  <span>&nbsp;</span> 
                </td> 
                </tr>
                <br/>
                    <tr>
                        <td>
                            
                 <label for="Mileage">Mileage(Km/L)</label>
                 </td>
                 <td>
                <input type="number" name="Mileage"></input> 
                </td>
                </tr>
                  <br /> 
                  <tr>
                    <td>
                <label for="Engine_displacement">Engine Displacement(CC)</label>
                </td>
                <td>
                <input type="number" name="Engine_displacement" placeholder="EngineDisplacement"></input>
                </td>
                  
                </tr>
                <br /> 
                <tr>
                    <td>
                <label for="SteeringType">Steering Type</label>
                </td>
                <td>
                <input type="text" name="SteeringType" placeholder="Steering Type"></input>  
                 {/* <span>&nbsp;</span>  */}
                </td>
                 
                </tr>
                <br /> 
                <tr>
                 <td>
                <label for="Gears"> No Of Gears</label>
                </td>
                <td>
                <select>
                    <option value="No Of Gears">No of Gears</option>
                    <option value="6">6</option>
                    <option value="5">5</option>
                </select>
                 {/* <span>&nbsp;</span>  */}
                </td>
                
                </tr>
                <br /> 
                <tr>
                <td>
                <label for="Cylinders">No. of Cylinders</label>
                </td>
                <td>
                <input type="number" name="Cylinderers" placeholder="No. of Cylinders"></input>
                </td>
                  <br /> <br />
                </tr>
                <tr>
                    <td>
                <input type="button" value="Save" /> 
                {/* <span>&nbsp;</span>  */}          
        <input type="button" value="Cancel" />
        </td>
        </tr>
      </body>
            </form>
            </div>
            </div>
        
    )
 }
 export default VehicleForm2;