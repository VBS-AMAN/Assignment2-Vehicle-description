﻿using Aman_VD_API.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Aman_VD_API.Controllers
{
    
    [ApiController]
    public class AmanVehicleDescriptionController : ControllerBase
    {
        private readonly Freshers_Training2022Context _context;
        public AmanVehicleDescriptionController(Freshers_Training2022Context context)
        {
            _context = context;
        }

        [Route("api/[controller]")]
        // GET: api/<AmanVehicleDescriptionController>
        [HttpGet]
        public IEnumerable<AmanVehicleDescription> Get()
        {
            return _context.AmanVehicleDescriptions.ToList();
        }

        //table:AmanVehicleDescriptions
        //AmanVehicleDescription
        [Route("api/[controller]")]
        // GET api/<AmanVehicleDescriptionController>/5
        [HttpGet("{id}")]
        public AmanVehicleDescription GetData(int id)
        {

            var data = _context.AmanVehicleDescriptions.Where(a => a.ManufacturerId == id).FirstOrDefault();
            return data;

        }
        [Route("api/[controller]")]
        // POST api/<AmanVehicleDescriptionController>
        [HttpPost]
        public IActionResult Post([FromBody] AmanVehicleDescription tbl)
        {
            if (!ModelState.IsValid)
                return BadRequest("Not a valid Model");

            _context.AmanVehicleDescriptions.Add(tbl);
            _context.SaveChanges();

            return Ok();
        }
        [Route("api/[controller]")]

        // PUT api/<AmanVehicleDescriptionController>/5
        [HttpPut("{id}")]
        public async Task<IActionResult> Put(int id, [FromBody] AmanVehicleDescription tbl)
        {
            try
            {
                if (id != tbl.ManufacturerId)
                {
                    return BadRequest("Id mismatch");
                }
                var UserUpdate = await _context.AmanVehicleDescriptions.FindAsync(id);
                if (UserUpdate != null)
                {
                    UserUpdate.ManufacturerId = tbl.ManufacturerId;
                    UserUpdate.LaunchYear = tbl.LaunchYear;
                    UserUpdate.VehicleName = tbl.VehicleName;
                    UserUpdate.VehicleType = tbl.VehicleType;
                    UserUpdate.Model = tbl.Model;
                    UserUpdate.Passangercapacity = tbl.Passangercapacity;
                    UserUpdate.MinimumCost = tbl.MinimumCost;
                    UserUpdate.MaximumCost = tbl.MaximumCost;
                    UserUpdate.EngineCapacity = tbl.EngineCapacity;
                    UserUpdate.FuelType = tbl.FuelType;
                    UserUpdate.DriveType = tbl.DriveType;
                    UserUpdate.SteeringType = tbl.SteeringType;
                    UserUpdate.Mileage = tbl.Mileage;
                    UserUpdate.GearId = tbl.GearId;
                    UserUpdate.EngineType = tbl.EngineType;
                    UserUpdate.EngineDisplacement = tbl.EngineDisplacement;
                    UserUpdate.Cylinders = tbl.Cylinders;
                    UserUpdate.LkpManufacturerId = tbl.LkpManufacturerId;
                    UserUpdate.VehicleTypeId = tbl.VehicleTypeId;
                    UserUpdate.PassangercapacityI = tbl.PassangercapacityI;
                    UserUpdate.GearId1 = tbl.GearId1;
                    await _context.SaveChangesAsync();
                    return Ok();
                }
                else
                {
                    return NoContent();
                }
            }
            catch (Exception)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, "error in data retrieval");
            }
        }
        [Route("api/[controller]")]
        // DELETE api/<AmanVehicleDescriptionController>/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            var data = await _context.AmanVehicleDescriptions.FindAsync(id);
            if (data == null)
            {
                return NotFound();
            }
            _context.AmanVehicleDescriptions.Remove(data);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        //---------------- for Lkpgear--------------

        //for Lkpgear
        [Route("api/[controller]/Lkpgear")]
        // GET: api/<LkpgearController>
        [HttpGet]
        public IEnumerable<Lkpgear> Get2()
        {
            return _context.Lkpgears.ToList();
        }

        //table: Lkpgear
        // Lkpgear
        // GET api/< LkpgearController>/5

        [Route("api/[controller]/Lkpgear")]
        [HttpGet("{id}")]
        public Lkpgear GetData2 (int id)
        {

            var data = _context.Lkpgears.Where(a => a.GearId1 == id).FirstOrDefault(); // gearid
            return data;

        }

        [Route("api/[controller]/Lkpgear")]

        // POST api/<AmanVehicleDescriptionController>
        [HttpPost]
        public IActionResult Post([FromBody] Lkpgear tbl)
        {
            if (!ModelState.IsValid)
                return BadRequest("Not a valid Model");

            _context.Lkpgears.Add(tbl);
            _context.SaveChanges();

            return Ok();
        }

        [Route("api/[controller]/Lkpgear")]
        // PUT api/< Lkpgear>/5
        [HttpPut("{id}")]
        public async Task<IActionResult> Put(int id, [FromBody] Lkpgear tbl)
        {
            try
            {
                if (id != tbl.GearId1)
                {
                    return BadRequest("Id mismatch");
                }
                var UserUpdate = await _context.AmanVehicleDescriptions.FindAsync(id);
                if (UserUpdate != null)
                {

                    UserUpdate.GearId = tbl.GearId; // no of gears
                    UserUpdate.GearId1 = tbl.GearId1;
                    await _context.SaveChangesAsync();
                    return Ok();
                }
                else
                {
                    return NoContent();
                }
            }
            catch (Exception)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, "error in data retrieval");
            }
        }

        [Route("api/[controller]/Lkpgear")]
        // DELETE api/< LkpgearController>/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete2 (int id)
        {
            var data = await _context.Lkpgears.FindAsync(id);
            if (data == null)
            {
                return NotFound();
            }
            _context.Lkpgears.Remove(data);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        //-------------- for Lkpmanufacturer-----------

        [Route("api/[controller]/Lkpmanufacturer")]

        // GET: api/<LkpmanufacturerController>
        [HttpGet]
        public IEnumerable<Lkpmanufacturer> Get3()
        {
            return _context.Lkpmanufacturers.ToList(); //why-s because of dependency injection??
        }

        //table:Lkpmanufacturers
        //Lkpmanufacturer
        // GET api/<LkpmanufacturerController>/5
        [Route("api/[controller]/Lkpmanufacturer")]
        [HttpGet("{id}")]
        public Lkpmanufacturer GetData3(int id)
        {

            var data = _context.Lkpmanufacturers.Where(a => a.LkpManufacturerId == id).FirstOrDefault();
            return data;

        }

        [Route("api/[controller]/Lkpmanufacturer")]
        // POST api/<AmanVehicleDescriptionController>
        [HttpPost]
        public IActionResult Post([FromBody] Lkpmanufacturer tbl)
        {
            if (!ModelState.IsValid)
                return BadRequest("Not a valid Model");

            _context.Lkpmanufacturers.Add(tbl);
            _context.SaveChanges();

            return Ok();
        }

        [Route("api/[controller]/Lkpmanufacturer")]

        // PUT api/<LkpmanufacturerController>/5
        [HttpPut("{id}")]
        public async Task<IActionResult> Put(int id, [FromBody] Lkpmanufacturer tbl)
        {
            try
            {
                if (id != tbl.LkpManufacturerId)
                {
                    return BadRequest("Id mismatch");
                }
                var UserUpdate = await _context.Lkpmanufacturers.FindAsync(id);
                if (UserUpdate != null)
                {
                    UserUpdate.Manufacturer = tbl.Manufacturer; ///???

                    UserUpdate.LkpManufacturerId = tbl.LkpManufacturerId;

                    await _context.SaveChangesAsync();
                    return Ok();
                }
                else
                {
                    return NoContent();
                }
            }
            catch (Exception)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, "error in data retrieval");
            }
        }

        [Route("api/[controller]/Lkpmanufacturer")]
        // DELETE api/<LkpmanufactureController>/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete3(int id)
        {
            var data = await _context.Lkpmanufacturers.FindAsync(id);
            if (data == null)
            {
                return NotFound();
            }
            _context.Lkpmanufacturers.Remove(data);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        //---------for LkpPassangerCapacity----

        [Route("api/[controller]/LkpPassangerCapacity")]
        // GET: api/<LkpPassangerCapacityController>
        [HttpGet]
        public IEnumerable<LkpPassangerCapacity> Get4()
        {
            return _context.LkpPassangerCapacities.ToList();
        }

        //table:LkpPassangerCapacitys
        //LkpPassangerCapacity
        // GET api/<LkpPassangerCapacityController>/5

        [Route("api/[controller]/LkpPassangerCapacity")]
        [HttpGet("{id}")]
        public LkpPassangerCapacity GetData4(int id)
        {

            var data = _context.LkpPassangerCapacities.Where(a => a.PassangercapacityId == id).FirstOrDefault();
            return data;

        }

        // POST api/<AmanVehicleDescriptionController>

        [Route("api/[controller]/LkpPassangerCapacity")]
        [HttpPost]
        public IActionResult Post([FromBody] LkpPassangerCapacity tbl)
        {
            if (!ModelState.IsValid)
                return BadRequest("Not a valid Model");

            _context.LkpPassangerCapacities.Add(tbl);
            _context.SaveChanges();

            return Ok();
        }

        // PUT api/<LkpPassangerCapacityController>/5

        [Route("api/[controller]/LkpPassangerCapacity")]
        [HttpPut("{id}")]
        public async Task<IActionResult> Put(int id, [FromBody] LkpPassangerCapacity tbl)
        {
            try
            {
                if (id != tbl.PassangercapacityId)
                {
                    return BadRequest("Id mismatch");
                }
                var UserUpdate = await _context.LkpPassangerCapacities.FindAsync(id);
                if (UserUpdate != null)
                {

                    UserUpdate.Passangercapacity = tbl.Passangercapacity;

                    UserUpdate.PassangercapacityId = tbl.PassangercapacityId;

                    await _context.SaveChangesAsync();
                    return Ok();
                }
                else
                {
                    return NoContent();
                }
            }
            catch (Exception)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, "error in data retrieval");
            }
        }

        // DELETE api/<PassangercapacityController>/5

        [Route("api/[controller]/LkpPassangerCapacity")]
        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete4(int id)
        {
            var data = await _context.LkpPassangerCapacities.FindAsync(id);
            if (data == null)
            {
                return NotFound();
            }
            _context.LkpPassangerCapacities.Remove(data);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        //----------------for LkpVehicleType--------

        [Route("api/[controller]/LkpVehicleType")]

        // GET: api/<LkpVehicleTypeController>
        [HttpGet]
        public IEnumerable<LkpVehicleType> Get5()
        {
            return _context.LkpVehicleTypes.ToList();
        }

        //table:LkpVehicleTypes
        //LkpVehicleType
        // GET api/<LkpVehicleTypeController>/5

        [Route("api/[controller]/LkpVehicleType")]
        [HttpGet("{id}")]
        public LkpVehicleType GetData5(int id)
        {

            var data = _context.LkpVehicleTypes.Where(a => a.VehicleTypeId == id).FirstOrDefault();
            return data;

        }

        // POST api/<VehicleTypeIdController>

        [Route("api/[controller]/LkpVehicleType")]
        [HttpPost]
        public IActionResult Post([FromBody] LkpVehicleType tbl)
        {
            if (!ModelState.IsValid)
                return BadRequest("Not a valid Model");

            _context.LkpVehicleTypes.Add(tbl);
            _context.SaveChanges();

            return Ok();
        }

        // PUT api/<LkpVehicleTypeController>/5

        [Route("api/[controller]/LkpVehicleType")]
        [HttpPut("{id}")]
        public async Task<IActionResult> Put(int id, [FromBody] LkpVehicleType tbl)
        {
            try
            {
                if (id != tbl.VehicleTypeId)
                {
                    return BadRequest("Id mismatch");
                }
                var UserUpdate = await _context.LkpVehicleTypes.FindAsync(id);
                if (UserUpdate != null)
                {

                    UserUpdate.VehicleType = tbl.VehicleType;

                    UserUpdate.VehicleTypeId = tbl.VehicleTypeId;

                    await _context.SaveChangesAsync();
                    return Ok();
                }
                else
                {
                    return NoContent();
                }
            }
            catch (Exception)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, "error in data retrieval");
            }
        }

        // DELETE api/<LkpVehicleTypeController>/5

        [Route("api/[controller]/LkpVehicleType")]
        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete5(int id)
        {
            var data = await _context.LkpVehicleTypes.FindAsync(id);
            if (data == null)
            {
                return NotFound();
            }
            _context.LkpVehicleTypes.Remove(data);
            await _context.SaveChangesAsync();

            return NoContent();
        }
    }
}



