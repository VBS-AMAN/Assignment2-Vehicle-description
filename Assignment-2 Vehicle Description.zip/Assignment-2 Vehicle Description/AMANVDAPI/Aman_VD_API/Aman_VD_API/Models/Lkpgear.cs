﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Aman_VD_API.Models
{
    public partial class Lkpgear
    {
        public Lkpgear()
        {
            AmanVehicleDescriptions = new HashSet<AmanVehicleDescription>();
        }

        public int? GearId { get; set; }
        public int GearId1 { get; set; }

        public virtual ICollection<AmanVehicleDescription> AmanVehicleDescriptions { get; set; }
    }
}
