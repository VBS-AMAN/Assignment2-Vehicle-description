﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Aman_VD_API.Models
{
    public partial class AmanVehicleDescription
    {
        public int ManufacturerId { get; set; }
        public int? LaunchYear { get; set; }
        public string VehicleName { get; set; }
        public string VehicleType { get; set; }
        public string Model { get; set; }
        public int? Passangercapacity { get; set; }
        public int? MinimumCost { get; set; }
        public int? MaximumCost { get; set; }
        public int? EngineCapacity { get; set; }
        public string FuelType { get; set; }
        public string DriveType { get; set; }
        public string SteeringType { get; set; }
        public int? Mileage { get; set; }
        public int? GearId { get; set; }
        public string EngineType { get; set; }
        public string EngineDisplacement { get; set; }
        public int? Cylinders { get; set; }
        public int? LkpManufacturerId { get; set; }
        public int? VehicleTypeId { get; set; }
        public int? PassangercapacityI { get; set; }
        public int? GearId1 { get; set; }

        public virtual Lkpgear GearId1Navigation { get; set; }
        public virtual Lkpmanufacturer LkpManufacturer { get; set; }
        public virtual LkpPassangerCapacity PassangercapacityINavigation { get; set; }
        public virtual LkpVehicleType VehicleTypeNavigation { get; set; }
    }
}
