﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Aman_VD_API.Models
{
    public partial class LkpVehicleType
    {
        public LkpVehicleType()
        {
            AmanVehicleDescriptions = new HashSet<AmanVehicleDescription>();
        }

        public string VehicleType { get; set; }
        public int VehicleTypeId { get; set; }

        public virtual ICollection<AmanVehicleDescription> AmanVehicleDescriptions { get; set; }
    }
}
