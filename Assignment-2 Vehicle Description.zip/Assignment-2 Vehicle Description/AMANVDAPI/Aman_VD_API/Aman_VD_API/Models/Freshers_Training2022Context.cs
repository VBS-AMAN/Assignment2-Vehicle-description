﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

#nullable disable

namespace Aman_VD_API.Models
{
    public partial class Freshers_Training2022Context : DbContext
    {
        public Freshers_Training2022Context()
        {
        }

        public Freshers_Training2022Context(DbContextOptions<Freshers_Training2022Context> options)
            : base(options)
        {
        }

        public virtual DbSet<AmanVehicleDescription> AmanVehicleDescriptions { get; set; }
        public virtual DbSet<LkpPassangerCapacity> LkpPassangerCapacities { get; set; }
        public virtual DbSet<LkpVehicleType> LkpVehicleTypes { get; set; }
        public virtual DbSet<Lkpgear> Lkpgears { get; set; }
        public virtual DbSet<Lkpmanufacturer> Lkpmanufacturers { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see http://go.microsoft.com/fwlink/?LinkId=723263.
                optionsBuilder.UseSqlServer("Data Source=192.168.1.230;Initial Catalog=Freshers_Training2022;Persist Security Info=True;User ID=trainee2022;Password=trainee@2022");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<AmanVehicleDescription>(entity =>
            {
                entity.HasKey(e => e.ManufacturerId)
                    .HasName("PK__Aman_Veh__800092605A10007F");

                entity.ToTable("Aman_VehicleDescription");

                entity.Property(e => e.ManufacturerId)
                    .ValueGeneratedNever()
                    .HasColumnName("Manufacturer_Id");

                entity.Property(e => e.DriveType)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.EngineDisplacement)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.EngineType)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.FuelType)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.GearId1).HasColumnName("Gear_Id");

                entity.Property(e => e.LkpManufacturerId).HasColumnName("lkp_Manufacturer_Id");

                entity.Property(e => e.Model)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.PassangercapacityI).HasColumnName("Passangercapacity_I");

                entity.Property(e => e.SteeringType)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.VehicleName)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.VehicleType)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.VehicleTypeId).HasColumnName("VehicleType_Id");

                entity.HasOne(d => d.GearId1Navigation)
                    .WithMany(p => p.AmanVehicleDescriptions)
                    .HasForeignKey(d => d.GearId1)
                    .HasConstraintName("FK__Aman_Vehi__Gear___5749A5B5");

                entity.HasOne(d => d.LkpManufacturer)
                    .WithMany(p => p.AmanVehicleDescriptions)
                    .HasForeignKey(d => d.LkpManufacturerId)
                    .HasConstraintName("FK__Aman_Vehi__lkp_M__546D390A");

                entity.HasOne(d => d.PassangercapacityINavigation)
                    .WithMany(p => p.AmanVehicleDescriptions)
                    .HasForeignKey(d => d.PassangercapacityI)
                    .HasConstraintName("FK__Aman_Vehi__Passa__5655817C");

                entity.HasOne(d => d.VehicleTypeNavigation)
                    .WithMany(p => p.AmanVehicleDescriptions)
                    .HasForeignKey(d => d.VehicleTypeId)
                    .HasConstraintName("FK__Aman_Vehi__Vehic__55615D43");
            });

            modelBuilder.Entity<LkpPassangerCapacity>(entity =>
            {
                entity.HasKey(e => e.PassangercapacityId)
                    .HasName("PK__lkpPassa__34E7CAA9D39CEFCF");

                entity.ToTable("lkpPassangerCapacity");

                entity.Property(e => e.PassangercapacityId)
                    .ValueGeneratedNever()
                    .HasColumnName("Passangercapacity_Id");
            });

            modelBuilder.Entity<LkpVehicleType>(entity =>
            {
                entity.HasKey(e => e.VehicleTypeId)
                    .HasName("PK__lkpVehic__A1D536D3B800A1C5");

                entity.ToTable("lkpVehicleType");

                entity.Property(e => e.VehicleTypeId)
                    .ValueGeneratedNever()
                    .HasColumnName("VehicleType_Id");

                entity.Property(e => e.VehicleType)
                    .HasMaxLength(100)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<Lkpgear>(entity =>
            {
                entity.HasKey(e => e.GearId1)
                    .HasName("PK__lkpgears__F3C73489A9994F6C");

                entity.ToTable("lkpgears");

                entity.Property(e => e.GearId1)
                    .ValueGeneratedNever()
                    .HasColumnName("Gear_Id");
            });

            modelBuilder.Entity<Lkpmanufacturer>(entity =>
            {
                entity.ToTable("lkpmanufacturer");

                entity.Property(e => e.LkpManufacturerId)
                    .ValueGeneratedNever()
                    .HasColumnName("lkp_Manufacturer_Id");

                entity.Property(e => e.Manufacturer)
                    .HasMaxLength(20)
                    .IsUnicode(false);
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
